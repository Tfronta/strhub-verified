# HipSTR con los slices hg38 de STRhub — 10 de noviembre de 2026

**Sí: HipSTR funcionó con ambos slices hg38 del repositorio.** Las dos ejecuciones terminaron con código 0 y generaron VCF 4.1 válidos dentro del perfil estructural `strhub-vcf-structure/1`, con genotipos presentes. La cobertura del panel fue parcial y se conserva completa en la evidencia.

| Caso | Muestra | Regiones solicitadas | Regiones con genotipo | Omitidas | Tiempo de ejecución¹ |
| --- | --- | ---: | ---: | ---: | ---: |
| Autosómico | NA12878 | 24 | 22 | 2 | 18,125 s |
| Cromosoma Y | HG002 | 17 | 11 | 6 | 1,407 s |

¹ Tiempo del comando Docker, incluida su puesta en marcha. No incluye descarga, preparación de referencia ni la compilación realizada en la prueba anterior. Son 17 filas de regiones Y, con componentes de marcadores compuestos; no equivalen a 17 marcadores forenses independientes.

Los 22 registros autosómicos tienen GT diploide y los 11 registros Y tienen GT haploide. No hay filas emitidas con todos los alelos GT ausentes. Los nombres de muestra coinciden con los previstos y todos los registros se corresponden con regiones de los BED de entrada.

Esta prueba demuestra ejecución y producción de genotipos en estos datos. No se compararon los alelos con una verdad de referencia, por lo que no demuestra exactitud científica ni validación forense. Sigue siendo una prueba manual; la integración automática de Verified queda pendiente.

## Qué se ejecutó

Se reutilizó el binario original ya compilado de [tfwillems/HipSTR, commit b2033bf](https://github.com/tfwillems/HipSTR/tree/b2033bfbb5cf55496b776463bdf2993fa763a4be). Su SHA256 es `4bf7579512e67ed580b64ca99daa4fb527024fdf1e11b8e763419feaba5093ef`.

Se usó la misma imagen Linux ARM64 de Ubuntu 22.04 de la prueba anterior: `sha256:68e575be59f1778976ed9cf606e9667cbfba1c1fe3790bdd925beee77ef417de`. En aquella preparación se ejecutó el `apt install` de los seis paquetes pedidos por el README y `make`, sin parches ni opciones adicionales de compilación. Esta vez no se recompiló ni se instaló ningún paquete. El paquete de evidencias incluye el informe y archivo completo de la prueba anterior para conservar el origen del binario y de la imagen; sus resultados hg19 no forman parte de los resultados hg38.

Entradas del repositorio STRhub Verified, commit `025ce998c4316afa15b7625a1671017c648d315b`:

- `illumina_slices/NA12878.autosomal.bam` y su índice; `datasets/illumina-bam-hg38/regions/hipstr.bed`.
- `illumina_slices/HG002.ystr.bam` y su índice; `datasets/illumina-bam-hg38-y/regions/hipstr.bed`.

Se copiaron byte por byte. Los BAM pasaron `samtools quickcheck`; contienen los campos de read group ID, LB y SM exigidos por HipSTR. La preparación previa de esos read groups ya forma parte de los fixtures del repositorio: esta prueba no cambió headers, ordenamiento, alineamientos ni índices BAM.

Los BED existentes tienen siete columnas. El lector del commit fijado consume las cinco obligatorias y el nombre opcional de la sexta; no consume la anotación de motivo en la séptima. Se entregaron los archivos originales completos, sin convertir columnas ni coordenadas.

## Referencia hg38

Se descargó exactamente [hg38.fa.gz de UCSC](https://hgdownload.soe.ucsc.edu/goldenPath/hg38/bigZips/hg38.fa.gz), la URL ya configurada por ambos `dataset.yml`. Se verificó con el [checksum publicado por UCSC](https://hgdownload.soe.ucsc.edu/goldenPath/hg38/bigZips/md5sum.txt), se descomprimió sin cambiar secuencias y se indexó con el `samtools` ya instalado en el host.

| Artefacto | Comprobación |
| --- | --- |
| Gzip descargado | MD5 publicado y observado: `1c9dcaddfa41027f17cd8f7a82c7293b` |
| Gzip descargado | SHA256: `c1dd87068c254eb53d944f71e51d1311964fce8de24d6fc0effc9c61c01527d4` |
| FASTA usado | SHA256: `5be01555d98347fdb3714dc84c6f77c9d8bc774adcf32c6f7a8fa06f5baf5e51` |

Todos los cromosomas utilizados tienen la misma longitud en el FASTA y en los headers BAM; todas las regiones están dentro de esos límites. La documentación del dataset declara compatibilidad de los cromosomas primarios con UCSC hg38. Los headers BAM no incluyen M5 para esos cromosomas: la comprobación de longitudes no constituye una comparación base por base con el FASTA original usado por el alineador. No se realineó ni se hizo liftover.

UCSC identifica esta URL como la versión inicial de hg38. Se mantuvo esa URL declarada por el repositorio. [Documentación de UCSC](https://hgdownload.soe.ucsc.edu/goldenPath/hg38/bigZips/).

## Comandos fijados antes de ejecutar

```text
/trial/HipSTR --bams /trial/inputs/autosomal.bam
  --fasta /trial/reference/hg38.fa --regions /trial/inputs/autosomal.bed
  --str-vcf /output/hipstr.vcf.gz --log /output/hipstr.log
  --min-reads 15 --def-stutter-model

/trial/HipSTR --bams /trial/inputs/y.bam
  --fasta /trial/reference/hg38.fa --regions /trial/inputs/y.bed
  --str-vcf /output/hipstr.vcf.gz --log /output/hipstr.log
  --min-reads 15 --def-stutter-model --haploid-chrs chrY
```

Cada bloque representa un único argv; los saltos son de presentación. Los argv reales completos, incluidos los de Docker, están guardados en los recibos.

La combinación `--min-reads 15 --def-stutter-model` se eligió antes de las ejecuciones a partir de la recomendación del [README fijado para pocas muestras](https://github.com/tfwillems/HipSTR/blob/b2033bfbb5cf55496b776463bdf2993fa763a4be/README.md#data-requirements). El modo haploide de Y también está [documentado por el autor](https://github.com/tfwillems/HipSTR/blob/b2033bfbb5cf55496b776463bdf2993fa763a4be/README.md#additional-usage-options). Son elecciones declaradas para estos casos; no se aplicaron después de observar un fallo.

Se mantuvieron los demás filtros originales, incluida la eliminación de duplicados y el máximo de 100 bases. Cada caso tuvo un solo intento. Los contenedores corrieron sin red, con entradas de solo lectura, salida independiente y límites de 6 GiB, 2 CPU y 512 procesos. Ambos terminaron sin OOM ni error de Docker.

## Omisiones conservadas

| Caso | Región | Motivo original del log |
| --- | --- | --- |
| Autosómico | SE33 | Longitud de referencia 102 bp, superior al máximo 100 |
| Autosómico | D21S11 | Longitud de referencia 127 bp, superior al máximo 100 |
| Y | Y-GATA-H4 | Longitud de referencia 122 bp, superior al máximo 100 |
| Y | DYS385_2 | Longitud de referencia 175 bp, superior al máximo 100 |
| Y | DYS19/DYS394 | HipSTR abortó el genotipado del locus por flanco posterior demasiado repetitivo |
| Y | DYS389II.2 | HipSTR abortó el genotipado del locus por flanco anterior demasiado repetitivo |
| Y | DYS448.1 | HipSTR abortó el genotipado del locus por flanco posterior demasiado repetitivo |
| Y | DYS448.2 | HipSTR abortó el genotipado del locus por flanco anterior demasiado repetitivo |

Estas decisiones por locus no detuvieron el proceso completo. No se aumentó el límite, no se desactivaron filtros, no se cambiaron las regiones y no se repitió ninguna ejecución. La tabla detallada conserva las 41 filas solicitadas, incluso las ocho sin registro de salida.

## Integridad y evidencia

- Los 396 archivos rastreados del repositorio de HipSTR conservan el mismo hash antes y después.
- El binario, los BAM, sus índices, los BED, el FASTA y su índice conservan sus hashes.
- Todos los recibos apuntan al mismo hash del plan previo: `7bd61162de33e81575022a562d45aab3ccd3e9e899f7aba381c9a05a4dd81d8e`.
- El checkout del motor de STRhub sigue limpio. No se modificó el motor, ni se publicaron badges, merges o despliegues.
- Los scripts de registro, preparación y lectura de resultados están fuera del repositorio de la herramienta y se incluyen en la evidencia. No sustituyen ni editan sus scripts.

[Resultados estructurados](/Users/tfronta/Documents/Codex/2026-11-08/q/outputs/hipstr-hg38-pruebas-2026-11-10/evidence/results.json) · [Resultado de cada región](/Users/tfronta/Documents/Codex/2026-11-08/q/outputs/hipstr-hg38-pruebas-2026-11-10/evidence/region-outcomes.tsv) · [Evidencias completas ZIP](/Users/tfronta/Documents/Codex/2026-11-08/q/outputs/hipstr-hg38-pruebas-2026-11-10.zip).

El ZIP incluye los VCF y logs originales, planes, recibos, hashes, headers, documentación y scripts de instrumentación. El FASTA, los BAM y el ejecutable quedan fuera del ZIP por tamaño; se identifican mediante hashes, commit y URL para reconstruir las entradas.

## Cómo seguir con la automatización

1. Representar en el motor la instalación y compilación documentadas, el comando nativo y la preparación explícita de entradas. Esta prueba reutilizó una imagen preparada; no prueba todavía ese recorrido automático desde un entorno vacío.
2. Guardar antes de ejecutar la fuente, versión, comandos, selección de dataset hg38, parámetros y límites. Ante un fallo, conservarlo y terminar ese intento sin reparación ni ajustes automáticos.
3. Mostrar por separado el estado del proceso, la validez estructural y las regiones llamadas u omitidas. El resultado de Y debe seguir mostrando 11/17; nunca presentarlo como cobertura completa del panel.
4. Corregir la documentación desactualizada del dataset Y, que todavía menciona cantidades y archivos anteriores. La evidencia actual usa los 17 renglones existentes. Documentar también que una buena cobertura BAM no garantiza que HipSTR llame todos los loci.

El siguiente cambio debe incorporar este recorrido explícito al motor y conservar sus resultados parciales. La prueba no justifica agregar parámetros para recuperar las regiones omitidas.
