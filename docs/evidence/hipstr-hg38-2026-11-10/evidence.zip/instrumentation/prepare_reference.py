"""Verify and unpack the exact dataset reference, without changing sequences."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from prepare_inputs import ROOT, digest, write_new

for stage in ("download-reference", "download-checksums", "prepare-inputs"):
    assert json.loads((ROOT / "evidence" / (stage + ".json")).read_text())["exit_code"] == 0
ref = ROOT / "reference"
expected = [line.split()[0] for line in (ref / "md5sum.txt").read_text().splitlines()
            if len(line.split()) == 2 and line.split()[1].lstrip("*") == "hg38.fa.gz"]
assert len(expected) == 1, "Missing or ambiguous published hg38.fa.gz checksum"
md5 = hashlib.md5()
with (ref / "hg38.fa.gz").open("rb") as f:
    for block in iter(lambda: f.read(8*1024*1024), b""):
        md5.update(block)
assert md5.hexdigest() == expected[0], "Reference MD5 mismatch; stop without fallback"
compressed_sha = digest(ref / "hg38.fa.gz")
with gzip.open(ref / "hg38.fa.gz", "rb") as source, (ref / "hg38.fa").open("xb") as target:
    shutil.copyfileobj(source, target, 8*1024*1024)
subprocess.run(["samtools", "faidx", str(ref / "hg38.fa")], check=True)
lengths = {parts[0]: int(parts[1]) for line in (ref / "hg38.fa.fai").read_text().splitlines()
           if (parts := line.split("\t"))}
plan = json.loads((ROOT / "plan.json").read_text())
cases = {}
for case in plan["cases"]:
    sq = {}
    for line in (ROOT / "evidence" / (case["id"] + ".header.sam")).read_text().splitlines():
        if line.startswith("@SQ\t"):
            tags = dict(field.split(":", 1) for field in line.split("\t")[1:])
            sq[tags["SN"]] = tags
    used = {}
    for line in (ROOT / "inputs" / (case["id"] + ".bed")).read_text().splitlines():
        chrom, start, stop, *_ = line.split()
        assert chrom in sq and chrom in lengths
        assert int(sq[chrom]["LN"]) == lengths[chrom], f"Contig length mismatch: {chrom}"
        assert 1 <= int(start) < int(stop) <= lengths[chrom], "Region outside reference"
        used[chrom] = {"bam_length": int(sq[chrom]["LN"]), "fasta_length": lengths[chrom],
                       "bam_assembly": sq[chrom].get("AS"), "bam_m5_present": "M5" in sq[chrom]}
    cases[case["id"]] = {"requested_rows": case["requested_rows"], "used_contigs": used}
write_new(ROOT / "evidence/reference-preflight.json", {
    "url": plan["reference"]["url"], "published_md5": expected[0], "observed_md5": md5.hexdigest(),
    "gzip_sha256": compressed_sha, "fasta_sha256": digest(ref / "hg38.fa"),
    "fai_sha256": digest(ref / "hg38.fa.fai"), "all_used_contig_lengths_match": True,
    "cases": cases,
    "scope": "Existing dataset provenance declares primary chromosome compatibility. Length checks are not base-by-base identity proof; BAM headers have no M5 for these contigs. No realignment or header changes."
})
print("Published reference MD5 matches. FASTA unpacked and indexed. All used contigs match BAM lengths and regions are in bounds.")
