"""Preserve raw artifacts byte-for-byte and verify every packaged file."""
import json
from pathlib import Path
import shutil
import zipfile
from prepare_inputs import ROOT, ENGINE, UPSTREAM, digest, write_new

OUT = ROOT.parent.parent / "outputs"
NAME = "hipstr-hg38-pruebas-2026-11-10"
target = OUT / NAME
target.mkdir(exist_ok=False)

def preserve(source, relative):
    destination = target / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    assert digest(source) == digest(destination), str(relative)

for source in sorted((ROOT / "evidence").iterdir()):
    if source.is_file():
        preserve(source, Path("evidence") / source.name)
for source in sorted((ROOT / "outputs").rglob("*")):
    if source.is_file():
        preserve(source, Path("results") / source.relative_to(ROOT / "outputs"))
for source in sorted((ROOT / "inputs").glob("*.bed")):
    preserve(source, Path("inputs") / source.name)
for source in sorted(ROOT.glob("*.py")):
    preserve(source, Path("instrumentation") / source.name)
preserve(ROOT / "plan.json", Path("plan.json"))
preserve(ROOT / "reference/md5sum.txt", Path("reference/md5sum.txt"))
preserve(ROOT / "reference/hg38.fa.fai", Path("reference/hg38.fa.fai"))
preserve(OUT / (NAME + ".md"), Path("report.md"))
for name in ("README.md", "Makefile"):
    preserve(UPSTREAM / name, Path("upstream-documentation") / name)
for source in sorted(UPSTREAM.glob("LICENSE*")):
    if source.is_file():
        preserve(source, Path("upstream-documentation") / source.name)
for name in ("dataset.yml", "SOURCE.txt"):
    preserve(ENGINE / "datasets/illumina-bam-hg38" / name, Path("dataset-provenance/autosomal") / name)
for name in ("dataset.yml", "README.md"):
    preserve(ENGINE / "datasets/illumina-bam-hg38-y" / name, Path("dataset-provenance/y") / name)
preserve(ENGINE / "harness/vcf_structure.py", Path("instrumentation/validator/vcf_structure.py"))
oldzip = OUT / "hipstr-prueba-2026-11-10.zip"
assert digest(oldzip) == "eb76ddf980fefbecb2d1e2106a581cde5092ac174a4a8c002e51f62795dc5b91"
preserve(oldzip, Path("build-origin") / oldzip.name)
preserve(OUT / "hipstr-prueba-2026-11-10.md", Path("build-origin/prior-report.md"))
manifest = {str(p.relative_to(target)): digest(p) for p in sorted(target.rglob("*")) if p.is_file()}
with (target / "SHA256SUMS").open("x") as f:
    f.writelines(value + "  " + key + "\n" for key, value in manifest.items())
archive = OUT / (NAME + ".zip")
with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(target.rglob("*")):
        if p.is_file():
            z.write(p, str(p.relative_to(target)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for relative, value in manifest.items():
        import hashlib
        assert hashlib.sha256(z.read(relative)).hexdigest() == value, relative
    assert z.read("SHA256SUMS") == (target / "SHA256SUMS").read_bytes()
result = {"files_in_manifest": len(manifest), "zip_bytes": archive.stat().st_size,
          "zip_sha256": digest(archive), "all_entries_verified": True}
write_new(ROOT / "packaging-verification.json", result)
print(json.dumps(result, indent=2))
