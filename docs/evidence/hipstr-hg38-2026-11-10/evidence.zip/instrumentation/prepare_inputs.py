"""Copy fixed inputs byte-for-byte and record provenance; never edit upstream."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT.parent / "step1"
UPSTREAM = ROOT.parent / "hipstr-real-20261109/HipSTR-tutorial/HipSTR"

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8*1024*1024), b""):
            h.update(block)
    return h.hexdigest()

def git(path, *args):
    return subprocess.check_output(["git", "-C", str(path), *args]).decode()

def snapshot():
    files = git(UPSTREAM, "ls-files", "-z").split("\0")
    return {name: digest(UPSTREAM / name) for name in files if name}

def write_new(path, obj):
    with path.open("x") as f:
        json.dump(obj, f, indent=2)
        f.write("\n")

if __name__ == "__main__":
    plan = json.loads((ROOT / "plan.json").read_text())
    assert git(ENGINE, "rev-parse", "HEAD").strip() == plan["engine_commit"]
    assert git(ENGINE, "status", "--porcelain") == "", "Engine checkout must be clean"
    assert git(UPSTREAM, "rev-parse", "HEAD").strip() == plan["source"]["commit"]
    assert digest(UPSTREAM / "HipSTR") == plan["source"]["binary_sha256"]
    assert digest(UPSTREAM / "README.md") == plan["source"]["readme_sha256"]
    copies = {UPSTREAM / "HipSTR": ROOT / "HipSTR"}
    for case in plan["cases"]:
        bam = ENGINE / case["bam_source"]
        bed = ENGINE / case["regions_source"]
        assert len(bed.read_text().splitlines()) == case["requested_rows"]
        copies[bam] = ROOT / "inputs" / (case["id"] + ".bam")
        copies[Path(str(bam) + ".bai")] = ROOT / "inputs" / (case["id"] + ".bam.bai")
        copies[bed] = ROOT / "inputs" / (case["id"] + ".bed")
    records = []
    for source, target in copies.items():
        assert not target.exists()
        before = digest(source)
        shutil.copy2(source, target)
        assert digest(target) == before
        records.append({"source": str(source), "copy": str(target.relative_to(ROOT)),
                        "size": target.stat().st_size, "sha256": before})
    for case in plan["cases"]:
        header = subprocess.check_output(["samtools", "view", "--no-PG", "-H", str(ENGINE / case["bam_source"])])
        (ROOT / "evidence" / (case["id"] + ".header.sam")).write_bytes(header)
        proc = subprocess.run(["samtools", "quickcheck", "-v", str(ENGINE / case["bam_source"])], capture_output=True)
        assert proc.returncode == 0, proc.stderr.decode()
        rows = []
        for line in header.decode().splitlines():
            if line.startswith("@RG"):
                tags = dict(field.split(":", 1) for field in line.split("\t")[1:])
                assert all(tags.get(key) for key in ("ID", "LB", "SM"))
                rows.append(tags)
        assert rows and {row["SM"] for row in rows} == {case["sample"]}
    write_new(ROOT / "evidence/input-snapshot-before.json", records)
    write_new(ROOT / "evidence/upstream-source-before.json", snapshot())
    write_new(ROOT / "evidence/preflight-inputs.json", {
        "time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "engine_commit": plan["engine_commit"], "engine_clean": True,
        "binary_reused": True, "copied_bytes_identical": True,
        "bam_quickcheck": "both exit 0", "read_groups": "ID,LB,SM present; expected samples",
        "source_tracking": "All tracked upstream files hashed before the hg38 runs",
        "no_source_modifications": git(UPSTREAM, "status", "--porcelain", "--untracked-files=no") == "",
        "samtools": subprocess.check_output(["samtools", "--version"]).decode().splitlines()[:2]
    })
    print("Inputs copied byte-for-byte; BAM integrity and read groups valid; engine clean.")
