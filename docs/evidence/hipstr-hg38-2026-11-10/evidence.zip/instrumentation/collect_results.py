"""Read and preserve all outcomes; never rewrite HipSTR inputs or outputs."""
import collections
import dataclasses
import datetime
import json
import re
import subprocess
import sys
from prepare_inputs import ROOT, ENGINE, UPSTREAM, digest, git, snapshot, write_new

sys.path.insert(0, str(ENGINE / "harness"))
import vcf_structure as vcf

plan = json.loads((ROOT / "plan.json").read_text())
results = {}
containers = {}
region_table = ["case\tlocus\tchrom\tstart_1based\tend_inclusive\tstatus\tGT\treason"]
for case in plan["cases"]:
    cid = case["id"]
    receipt = json.loads((ROOT / "evidence" / ("genotype-" + cid + ".json")).read_text())
    state, = json.loads(subprocess.check_output(["docker", "inspect", case["container"]]))
    containers[cid] = {key: state[key] for key in ("Id", "Name", "Image", "State", "Mounts")}
    containers[cid]["limits"] = {key: state["HostConfig"][key] for key in (
        "NetworkMode", "Memory", "MemorySwap", "NanoCpus", "PidsLimit", "CapDrop", "SecurityOpt")}
    containers[cid]["user"] = state["Config"]["User"]
    path = ROOT / "outputs" / cid / "hipstr.vcf.gz"
    result = {"exit_code": receipt["exit_code"], "seconds": receipt["seconds"],
              "attempts": 1, "sample_expected": case["sample"], "requested_rows": case["requested_rows"]}
    text = vcf.read(path)
    try:
        summary = vcf.validate(text)
        result["vcf_validation"] = {"profile": vcf.PROFILE, "status": "valid_within_profile", **dataclasses.asdict(summary)}
    except vcf.UnsupportedVCF as exc:
        result["vcf_validation"] = {"profile": vcf.PROFILE, "status": "unsupported", "reason": str(exc)}
    except vcf.VCFError as exc:
        result["vcf_validation"] = {"profile": vcf.PROFILE, "status": "invalid", "reason": str(exc)}
    records = []
    for line in text.splitlines():
        if line.startswith("#CHROM\t"):
            result["samples_observed"] = line.split("\t")[9:]
        elif not line.startswith("#"):
            f = line.split("\t")
            info = dict(pair.split("=", 1) for pair in f[7].split(";") if "=" in pair)
            formats = f[8].split(":")
            vals = dict(zip(formats, f[9].split(":")))
            records.append({"id": f[2], "chrom": f[0], "pos": int(f[1]), "start": int(info["START"]),
                            "end": int(info["END"]), "GT": vals.get("GT"), "DP": vals.get("DP"),
                            "GB": vals.get("GB"), "filter": f[6]})
    result["records"] = records
    result["gt_allele_slot_counts"] = dict(collections.Counter(
        str(len(re.split(r"[/|]", record["GT"]))) for record in records if record["GT"]))
    result["vcf_sha256"] = digest(path)
    result["log_sha256"] = digest(ROOT / "outputs" / cid / "hipstr.log")
    blocks = {}
    current = None
    log = (ROOT / "outputs" / cid / "hipstr.log").read_text()
    for lineno, line in enumerate(log.splitlines(), 1):
        match = re.fullmatch(r"Processing region (\S+) (\d+) (\d+)", line)
        if match:
            current = (match[1], int(match[2]) + 1, int(match[3]))
            blocks.setdefault(current, [])
        elif current and ("Skipping " in line or "Aborting " in line):
            blocks[current].append({"line": lineno, "message": line})
    outcomes = []
    for line in (ROOT / "inputs" / (cid + ".bed")).read_text().splitlines():
        chrom, start, end, period, copies, name, *extra = line.split()
        key = (chrom, int(start), int(end))
        found = [r for r in records if (r["chrom"], r["start"], r["end"], r["id"]) == (*key, name)]
        reasons = blocks.get(key, [])
        status = "vcf_record" if found else "omitted"
        if found and all(not re.search(r"\d", r["GT"] or "") for r in found):
            status = "record_without_call"
        outcome = {"id": name, "chrom": chrom, "start": int(start), "end": int(end),
                   "status": status, "records": found, "log_reasons": reasons}
        outcomes.append(outcome)
        region_table.append("\t".join([cid, name, chrom, start, end, status,
            ",".join(r["GT"] or "." for r in found) or ".",
            "; ".join(reason["message"] for reason in reasons) or "."]))
    result["region_outcomes"] = outcomes
    result["records_match_requested_regions"] = sum(len(o["records"]) for o in outcomes) == len(records)
    result["region_status_counts"] = dict(collections.Counter(o["status"] for o in outcomes))
    results[cid] = result

before = json.loads((ROOT / "evidence/upstream-source-before.json").read_text())
after = snapshot()
write_new(ROOT / "evidence/upstream-source-after.json", after)
changed = [name for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)]
input_after = []
for item in json.loads((ROOT / "evidence/input-snapshot-before.json").read_text()):
    original, copied = digest(__import__("pathlib").Path(item["source"])), digest(ROOT / item["copy"])
    input_after.append({**item, "source_sha256_after": original, "copy_sha256_after": copied,
                        "unchanged": original == copied == item["sha256"]})
reference = json.loads((ROOT / "evidence/reference-preflight.json").read_text())
reference_after = {"gzip_sha256": digest(ROOT / "reference/hg38.fa.gz"),
                   "fasta_sha256": digest(ROOT / "reference/hg38.fa"),
                   "fai_sha256": digest(ROOT / "reference/hg38.fa.fai")}
all_receipts = [json.loads(p.read_text()) for p in sorted((ROOT / "evidence").glob("*.json"))
                if p.name in ["prepare-inputs.json", "download-reference.json", "download-checksums.json",
                              "prepare-reference.json", "genotype-autosomal.json", "genotype-y.json"]]
integrity = {"time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "upstream_tracked_files": len(before), "upstream_changed_files": changed,
    "upstream_tracked_git_clean": git(UPSTREAM, "status", "--porcelain", "--untracked-files=no") == "",
    "engine_git_clean": git(ENGINE, "status", "--porcelain") == "",
    "all_inputs_unchanged": all(item["unchanged"] for item in input_after),
    "reference_unchanged": all(reference[key] == value for key, value in reference_after.items()),
    "reference_after": reference_after,
    "all_receipts_use_original_plan": all(item["plan_sha256"] == digest(ROOT / "plan.json") for item in all_receipts),
    "genotype_receipts": [item["stage"] for item in all_receipts if item["stage"].startswith("genotype-")],
    "vcf_validator_sha256": digest(ENGINE / "harness/vcf_structure.py")}
write_new(ROOT / "evidence/input-snapshot-after.json", input_after)
write_new(ROOT / "evidence/docker-containers.json", containers)
write_new(ROOT / "evidence/integrity-after.json", integrity)
write_new(ROOT / "evidence/results.json", results)
with (ROOT / "evidence/region-outcomes.tsv").open("x") as f:
    f.write("\n".join(region_table) + "\n")
print(json.dumps({cid: {key: value for key, value in result.items() if key not in ("records", "region_outcomes")}
                  for cid, result in results.items()}, indent=2))
print(json.dumps(integrity, indent=2))
