"""Record one command once; never repair, retry or modify the upstream source."""
import argparse
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument("stage")
parser.add_argument("--cwd", required=True)
parser.add_argument("--timeout", type=int, default=1800)
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ["--"] else args.command
root = pathlib.Path(__file__).resolve().parent
evidence = root / "evidence"
evidence.mkdir(exist_ok=True)
log = evidence / (args.stage + ".log")
receipt = evidence / (args.stage + ".json")
if receipt.exists():
    raise SystemExit("Refusing to overwrite an existing receipt")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
before = time.monotonic()
with log.open("xb") as handle:
    print(json.dumps({"stage": args.stage, "argv": command, "log": str(log)}), flush=True)
    try:
        process = subprocess.run(command, cwd=args.cwd, stdout=handle,
            stderr=subprocess.STDOUT, timeout=args.timeout, check=False)
        code, reason = process.returncode, "completed"
    except subprocess.TimeoutExpired:
        code, reason = 124, "predeclared time limit; no retry"
    except OSError as exc:
        handle.write(str(exc).encode())
        code, reason = 125, "environment could not start command"
result = {"stage": args.stage, "argv": command, "cwd": args.cwd,
    "started_at_utc": started, "finished_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "seconds": round(time.monotonic() - before, 3), "exit_code": code, "status": reason,
    "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
    "plan_sha256": hashlib.sha256((root / "plan.json").read_bytes()).hexdigest()}
with receipt.open("x") as handle:
    json.dump(result, handle, indent=2)
    handle.write("\n")
with (evidence / "events.ndjson").open("a") as handle:
    handle.write(json.dumps(result) + "\n")
print(json.dumps(result), flush=True)
print("\n".join(log.read_text(errors="replace").splitlines()[-10:]), flush=True)
sys.exit(code if 0 <= code <= 255 else 1)
