"""Execute the predeclared case exactly once and save the Docker argv receipt."""
import json
from pathlib import Path
import subprocess
import sys
from prepare_inputs import ROOT, digest

plan = json.loads((ROOT / "plan.json").read_text())
assert len(sys.argv) == 2
case, = [case for case in plan["cases"] if case["id"] == sys.argv[1]]
for stage in ("prepare-inputs", "prepare-reference"):
    assert json.loads((ROOT / "evidence" / (stage + ".json")).read_text())["exit_code"] == 0
for item in json.loads((ROOT / "evidence/input-snapshot-before.json").read_text()):
    assert digest(ROOT / item["copy"]) == item["sha256"]
command = ["docker", "run", "--name", case["container"], "--init", "--network", "none",
           "--user", "501:20", "--memory", "6g", "--memory-swap", "6g", "--cpus", "2",
           "--pids-limit", "512", "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
           "--mount", f"type=bind,source={ROOT},target=/trial,readonly",
           "--mount", f"type=bind,source={ROOT / 'outputs' / case['id']},target=/output",
           "--workdir", "/output", plan["environment"]["image"], *case["argv"]]
result = subprocess.run([sys.executable, str(ROOT / "record_exec.py"), "--cwd", str(ROOT),
                         "--timeout", str(plan["environment"]["timeout_seconds_per_case"]),
                         "genotype-" + case["id"], "--", *command], check=False)
sys.exit(result.returncode)
