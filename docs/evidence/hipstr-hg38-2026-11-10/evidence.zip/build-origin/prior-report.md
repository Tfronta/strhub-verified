# HipSTR: prueba real del tutorial upstream

Fecha de ejecución: **10 de noviembre de 2026**. Preparación iniciada el 9 de noviembre. Ensayo manual de referencia; no es una atestación automática ni publica un badge de Verified.

**Resultado: el procedimiento compiló y ejecutó HipSTR con código de salida 0 y produjo un VCF estructuralmente válido para tres muestras.** Se realizó una compilación y una ejecución de genotipado, sin parches, ajustes de compilador, cambios de parámetros o reintentos para recuperar loci.

## Procedimiento y fuentes

- Código: [`tfwillems/HipSTR`, commit b2033bf](https://github.com/tfwillems/HipSTR/tree/b2033bfbb5cf55496b776463bdf2993fa763a4be). Su archivo `src/version.cpp` declara `v0.7`; la identidad de esta prueba es el SHA completo, no el estado actual de una etiqueta.
- Instalación: [README del mismo commit](https://github.com/tfwillems/HipSTR/blob/b2033bfbb5cf55496b776463bdf2993fa763a4be/README.md#requirements). Se usó `make` sin argumentos ni overrides, después de instalar los seis paquetes que enumera para Ubuntu: `make`, `g++`, `zlib1g-dev`, `libhts-dev`, `libbz2-dev` y `liblzma-dev`.
- Ejemplo: [tutorial oficial, commit e9ef64c](https://github.com/HipSTR-Tool/HipSTR-tutorial/blob/e9ef64c2e9d021d2164e099bdde37a85cb2ff14d/README.md#running-hipstr). Se conservaron los **12 BAMs**, sus índices, las **599 regiones**, hg19 completo y todos los argumentos publicados, incluidos `--min-reads 25 --def-stutter-model`, el log y la salida de visualización.

El bloque de ejemplo está presentado en varias líneas sin continuaciones de shell. Se representó como una única lista de argumentos; un control previo comprobó que esa lista coincidiera con el bloque del tutorial fijado. No se eliminaron opciones ni se redujo la lista de BAMs.

El tutorial documenta descargar `chromFa.tar.gz`, extraerlo, concatenar `chr*.fa` e indexar el resultado con `samtools faidx`. Se siguieron esos pasos con la URL HTTP original, que respondió 200. No se sustituyó el genoma por un recorte o por hg38. Se registró el SHA-256 local; no se afirma disponer de un checksum firmado por upstream.

## Entorno observado

| Elemento | Valor |
| --- | --- |
| Sistema | Ubuntu 22.04, Linux ARM64 nativo, en Docker |
| Docker Engine | 29.2.1 |
| Compilador | G++ 11.4.0 |
| Preparación del FASTA | SAMtools 1.21 del host, con HTSlib 1.22 |
| Imagen del entorno preparado | `sha256:68e575be59f1778976ed9cf606e9667cbfba1c1fe3790bdd925beee77ef417de` |
| Compilación, ayuda y genotipado | Sin red, usuario 501:20, 2 CPU y límite de 6 GiB, capacidades eliminadas |

La preparación de paquetes y la descarga de datos requirieron red. La compilación y las ejecuciones de HipSTR no tuvieron red. Los contenedores finalizaron con código 0 y sin OOM. Las dependencias transitivas que resolvió APT y las versiones de los paquetes están registradas en el paquete de evidencia.

## Resultados

| Comprobación | Resultado |
| --- | --- |
| `make` | Código 0, aproximadamente 136 segundos, con sus warnings conservados |
| `./HipSTR --help` documentado | Código 0 |
| Genotipado del tutorial | Código 0, aproximadamente 82 segundos |
| Regiones de entrada | 599 |
| Loci excluidos por longitud máxima | 2; longitudes 119 y 127 frente al límite predeterminado de 100 |
| Otros loci sin registro | 7; el log informa flancos demasiado repetitivos |
| Registros del VCF | 590, para NA12878, NA12891 y NA12892 |
| Registros con al menos un alelo GT llamado | 585 |
| Registros con todos los GT ausentes | 5 |
| Validación estructural | VCF 4.1 válido según `strhub-vcf-structure/1` |
| Salida de visualización | Gzip íntegro, sin modificar |

Los cinco registros con todos los GT ausentes se conservan con `NFILT=3`. Esta revisión no establece su causa concreta ni los atribuye automáticamente a falta de lecturas. No se aumentó `--max-str-len`, se relajaron filtros ni se repitió el comando para recuperar registros o llamadas.

Se verificó que **los 396 archivos versionados de HipSTR y los 37 del tutorial mantuvieron exactamente sus bytes**, incluidos los BAMs e índices. El binario utilizado también conservó el mismo hash antes y después del genotipado. Los archivos generados por la compilación y la ejecución se conservaron como tales.

## Incidencia de adquisición conservada

El primer checkout se obtuvo desde `HipSTR-Tool/HipSTR`, enlace que aparece en el README. Allí falló la fijación del SHA elegido con `unable to read tree`; ese intento no llegó a compilar ni ejecutar HipSTR.

El tutorial indica expresamente `git clone https://github.com/tfwillems/HipSTR.git`. Se siguió esa ruta documentada y se pudo fijar **el mismo SHA**, antes de la primera compilación. El checkout inicial, su código 128, el plan original y la corrección de procedencia se conservaron. No se presenta el primer intento de adquisición como exitoso ni se cambió de commit para lograr la compilación.

## Evidencia y alcance

El paquete `hipstr-prueba-2026-11-10.zip` incluye:

- VCF, log completo y archivo de visualización originales.
- Plan previo, corrección documentada de adquisición, comandos, fechas, códigos de salida y hashes de logs.
- Verificación del comando contra el tutorial, del binario y de las fuentes antes/después.
- Hashes de inputs, referencia, imágenes y outputs; versiones de paquetes y estado final de los contenedores.
- Validación VCF y diagnósticos de las regiones omitidas.
- Inventario `SHA256SUMS`. Es evidencia local sin firma, no una atestación pública.

SHA-256 del VCF original: `8d54521ff6eda30f08b7d846a3a0d3b05ec4d2e921907016e23cce7be3743ce7`.

Este resultado demuestra ejecución funcional de ese procedimiento en este entorno. La validación estructural no demuestra exactitud biológica, concordancia de genotipos o aptitud forense.

## Consecuencia para STRhub

La prueba aporta el caso positivo real que faltaba. **Todavía no valida el circuito automático de Verified**: su perfil del paso 4 bloquea instalaciones como esta, basadas en requisitos explícitos y `make`, y exige un wrapper/entrypoint Bash que aquí no fue necesario para ejecutar el binario y capturar sus salidas documentadas.

El siguiente trabajo debe representar este procedimiento respaldado en el motor y probar su recorrido automático con los mismos comandos y datos. La herramienta debe permanecer intacta; la integración no necesita paquetes genéricos, cambios de parámetros ni excepciones para hacerla aprobar. El código del motor permaneció limpio en `025ce998c4316afa15b7625a1671017c648d315b`; no hubo merge, despliegue o modificación de badges.
